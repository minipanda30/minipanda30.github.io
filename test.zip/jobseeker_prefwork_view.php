<?php 
include ('fragments/profile_header.php');
include('fragments/profile_nav.php');
?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
             <div class="col-md-3">
                  <!-- profile image -->
                 <div class="box box-primary">
                      <div class="box-body box-profile">
                        <a href="jobseekerupload"><img class="profile-user-img img-responsive" src="<?php echo $jprofpic;?>" alt="User profile picture" style="width: 100px;height: 100px;"></a>

                        <h3 class="profile-username text-center"><?php echo $jfname.' '.$jlname;?></h3>
                        <ul class="list-group list-group-unbordered">
                          <li class="list-group-item">
                           <a href="jobseeker"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Personal Information</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerother"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-reorder"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Additional Information</b></span></button> </a>
                          </li>
                         <li class="list-group-item">
                            <a href="jobseekerprefwork"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-cubes"></i> &nbsp;&nbsp;&nbsp;&nbsp;<b>Job Preference</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerlanguage"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-comments-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Langauge and Dialect Proficiency</b></span></button> </a>
                          </li>
                          
                          <li class="list-group-item">
                            <a href="jobseekereduc"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-graduation-cap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Educational Background</b></span></button> </a>
                          </li>
                           <li class="list-group-item">
                            <a href="jobseekertrain"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-sitemap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Techinical/Vocational &amp; Other Trainings</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerelig"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-credit-card"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Eligibility/ Professional License</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerexp"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-suitcase"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Work Experience</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerskills"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-list-alt"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Other Skills</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerresume"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-files-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Upload Resume</b></span></button> </a>
                          </li>
                        </ul>
                      </div>
                      <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
              </div>

              <!-- PROFILE DETAILS -->
             <div class="col-md-9">
              <form action="Jobseeker/update_pref" method="post">
              <div class="box box-primary">
            <div class="box-header with-border">
              <i class="fa fa-list-ol"></i><h3 class="box-title">Preferences</h3> 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
             <div class="card mb-3">
                               
                                   
                          
                                <div class="card-body"  style="padding: 15px 20px 10px 20px">
                                  <div class="row" >
  <div class="col-lg-4" id="prefwork">
   <div class="row"><div class="col-lg-12 center-block"><label class='control-label '>Preferred Work</label></div></div>
<div class="row">
    <div class="col-lg-12 center-block">
       
       <div class="input-group">
      
      <select class="form-control pref"  name='prefworkin[]' ><option selected hidden><?php echo $pw[0]; ?></option></select>
      <span class="input-group-addon">
        <button class="btn btn-secondary" type="button" id="addpw"><i class="fa fa-plus"></i></button>
      </span>
    </div>

    </div>
  </div>



   <?php if($pw){$x = count($pw);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><select class="form-control pref"  name="prefworkin[]"><option selected hidden>'.$pw[$i].'</option></select><span class="input-group-addon"><button class="btn btn-danger delete'.$i.'" type="button"><i class="fa fa-times"></i></button></span></div></div></div>';}}?>
    
  </div>
  <div class="col-lg-4" id="prefwork2">
   <div class="row"><div class="col-lg-12 center-block"><label class='control-label '>Preferred Working Location (Local)</label></div></div>
<div class="row">
    <div class="col-lg-12 center-block">
       
       <div class="input-group">
      
      <input type="text" class="form-control"  name='prefworkin2[]' value='<?php echo $pwl[0]; ?>'>
      <span class="input-group-addon">
        <button class="btn btn-secondary" type="button" id="addpw2"><i class="fa fa-plus"></i></button>
      </span>
    </div>

    </div>
  </div>
  <?php if($pwl){$x2 = count($pwl);}else{$x2 = 0;} if($x2 > 1){for($i2=1;$i2<$x2;$i2++){echo '<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><input type="text" class="form-control"  name="prefworkin2[]" value="'.$pwl[$i2].'"><span class="input-group-addon"><button class="btn btn-danger delete2'.$i2.'" type="button"><i class="fa fa-times"></i></button></span></div></div></div>';}}?>
    


    
  </div>
  <div class="col-lg-4" id="prefwork3">
   <div class="row"><div class="col-lg-12 center-block"><label class='control-label '>Preferred Working Location (Abroad)</label></div></div>
<div class="row">
    <div class="col-lg-12 center-block">
       
       <div class="input-group">
      
      <input type="text" class="form-control"  name='prefworkin3[]' value="<?php echo $pwo[0]; ?>">
      <span class="input-group-addon">
        <button class="btn btn-secondary" type="button" id="addpw3"><i class="fa fa-plus"></i></button>
      </span>
    </div>
 
    </div>
  </div>

   <?php if($pwo){$x3 = count($pwo);}else{$x3 = 0;} if($x3 > 1){for($i3=1;$i3<$x3;$i3++){echo '<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><input type="text" class="form-control"  name="prefworkin3[]" value="'.$pwo[$i3].'"><span class="input-group-addon"><button class="btn btn-danger delete3'.$i3.'" type="button"><i class="fa fa-times"></i></button></span></div></div></div>';}}?>
   
    
  </div>
 
</div>
 <div class="row">
    <div class="col-lg-4"></div>
    <div class="col-lg-4"></div>
  <div class="col-lg-4">
    <br>
   <input type="submit" class="btn btn-info btn-block pull-right" value="Update"></div></div>
                                </div><!-- END CARD-BODY -->
                            </div><!-- END CARD-->
                           
            </div>
            <!-- /.box-body -->
          </div>
                   </form>      
                </div>

                      </div><!-- END BOX BODY -->
                  </div><!-- END BOX PRIMARY -->
            




<?php 
// include('fragments/jobseeker/jobseeker_profile_fragments.php');
// include('fragments/jobseeker/jobseeker_profile_fragments_edit.php');
include('fragments/profile_footer.php');
?>




<script src="assets/js/jobseeker_profile.js"></script>
<script>
  var max_fields      = 10;
    var wrapper         = $("#prefwork");
    var add_button      = $("#addpw");
  
    var x = 1;
    $(add_button).click(function(e){
     
         
        if(x < max_fields){


  
  
            $(wrapper).append('<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><select class="form-control pref" name="prefworkin[]"></select><span class="input-group-addon"><button class="btn btn-danger delete" type="button"><i class="fa fa-times"></i></button></span></div></div></div>');

            $.ajax({
      url : 'jobseekerprefwork/skills',
      type: "GET",
      dataType: "JSON",
      success: function(data)
      {     
        $.each(data,function(index,el){

            $('.pref').append('<option>'+ el.Specialization_Name +'</option>');

        });
                           
      },
      error: function (jqXHR, textStatus, errorThrown)
      {
        // console.log(jqXHR);
        alert("Error getting data!");
      }
    });

        }
  else
  {
  alert('You Reached the limits')
  }


   $('.delete').click(function(e){
       $(this).closest('.row').remove(); x--;
    });

    });

     <?php
  if($pw != null){$x = count($pw);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '$(".delete'.$i.'").click(function(e){
        e.preventDefault();$(".delete'.$i.'").closest(".row").remove();
    });';}}
?>




    var max_fields2      = 10;
    var wrapper2         = $("#prefwork2");
    var add_button2      = $("#addpw2");
  
    var y = 1;
    $(add_button2).click(function(e){
     
         
        if(y < max_fields2){


  
  
            $(wrapper2).append('<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><input type="text" class="form-control"  name="prefworkin2[]"><span class="input-group-addon"><button class="btn btn-danger delete2" type="button"><i class="fa fa-times"></i></button></span></div></div></div>');

        }
  else
  {
  alert('You Reached the limits')
  }


   $('.delete2').click(function(e){
        e.preventDefault();$(this).closest('.row').remove(); x--;
    });

    });

   <?php
  if($pwl != null){$x = count($pwl);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '$(".delete2'.$i.'").click(function(e){
        e.preventDefault();$(".delete2'.$i.'").closest(".row").remove();
    });';}}
?>


    var max_fields3      = 10;
    var wrapper3        = $("#prefwork3");
    var add_button3  = $("#addpw3");
  
    var z = 1;
    $(add_button3).click(function(e){
     
         
        if(z < max_fields3){


  
  
            $(wrapper3).append('<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><input type="text" class="form-control" name="prefworkin3[]"><span class="input-group-addon"><button class="btn btn-danger delete3" type="button"><i class="fa fa-times"></i></button></span></div></div></div>');

        }
  else
  {
  alert('You Reached the limits')
  }


   $('.delete3').click(function(e){
        e.preventDefault();$(this).closest('.row').remove(); x--;
    });

    });

   <?php
  if($pwo != null){$x = count($pwo);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '$(".delete3'.$i.'").click(function(e){
        e.preventDefault();$(".delete3'.$i.'").closest(".row").remove();
    });';}}
?>


$.ajax({
      url : 'jobseekerprefwork/skills',
      type: "GET",
      dataType: "JSON",
      success: function(data)
      {     
        $.each(data,function(index,el){

            $('.pref').append('<option>'+ el.Specialization_Name +'</option>');

        });
                           
      },
      error: function (jqXHR, textStatus, errorThrown)
      {
        // console.log(jqXHR);
        alert("Error getting data!");
      }
    });
  

 </script>


