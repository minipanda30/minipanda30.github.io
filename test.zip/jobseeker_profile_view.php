<?php 
include ('fragments/profile_header.php');
include('fragments/profile_nav.php');
?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
             <div class="col-md-3">
                  <!-- profile image -->
                  <div class="box box-primary">
                      <div class="box-body box-profile">
                      <a href="jobseekerupload"><img class="profile-user-img img-responsive" src="<?php echo $jprofpic;?>" alt="User profile picture" style="width: 100px;height: 100px;"></a>

                        <h3 class="profile-username text-center"><?php echo $jfname.' '.$jlname;?></h3>
                       <ul class="list-group list-group-unbordered">
                          <li class="list-group-item">
                           <a href="jobseeker"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Personal Information</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerother"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-reorder"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Additional Information</b></span></button> </a>
                          </li>
                         <li class="list-group-item">
                            <a href="jobseekerprefwork"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-cubes"></i> &nbsp;&nbsp;&nbsp;&nbsp;<b>Job Preference</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerlanguage"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-comments-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Langauge and Dialect Proficiency</b></span></button> </a>
                          </li>
                          
                          <li class="list-group-item">
                            <a href="jobseekereduc"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-graduation-cap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Educational Background</b></span></button> </a>
                          </li>
                           <li class="list-group-item">
                            <a href="jobseekertrain"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-sitemap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Techinical/Vocational &amp; Other Trainings</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerelig"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-credit-card"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Eligibility/ Professional License</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerexp"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-suitcase"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Work Experience</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerskills"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-list-alt"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Other Skills</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerresume"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-files-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Upload Resume</b></span></button> </a>
                          </li>
                        </ul>
                      </div>
                      <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
              </div>

              <!-- PROFILE DETAILS -->
             <div class="col-md-9" id="myprofile">
              <form action="Jobseeker/add_personal_information" method="post">
              <div class="row">
                <div class="col-lg-12">
                    <div class="box box-primary">
                      <div class="box-header with-border">
                         <i class="fa fa-info-circle"></i><h3 class="box-title"> Primary Information </h3>
                      </div>              
                      <div class="box-body" id="background"> 
                            <!-- PRIMARY INFORMATION -->
                            <div class="card mb-3">
                                
                                <div class="card-body">
                                    <div class="row"> 
                                      <div class="col-lg-4 center-block">
                                          <label class='control-label'>First Name</label>
                                         <input type="text" name="fname" placeholder="First Name" class ='form-control pull-left ' required value="<?php echo $FName;?>">
                                      </div>
                                       <div class="col-lg-3 center-block">
                                         <label class='control-label'>Middle Name</label>
                                         <input type="text" placeholder="Middle Name" name="mname" class ='form-control pull-left' required value="<?php echo $MName;?>">
                                      </div>
                                       <div class="col-lg-3 center-block">
                                         <label class='control-label'>Last Name</label>
                                         <input type="text" placeholder="Last Name" name="lname" class ='form-control pull-left ' required value="<?php echo $LName;?>">
                                      </div>
                                        <div class="col-lg-2 center-block">
                                         <label class='control-label'>Suffix</label>
                                         <input type="text" placeholder="Suffix" name="suff" class ='form-control pull-left ' value="<?php echo $NSuff;?>">
                                      </div>
    
                                    </div>

                                    <div class="row">  
                                        <div class="col-lg-3 center-block">
                                          <label class='control-label'>Date of Birth</label>
                                           <select name="month" id="monthcom" class="form-control pull-left" >
                                            
                                            <option value="<?php echo date('F',strtotime($Birthdate)) ?>" selected hidden><?php echo date('F',strtotime($Birthdate)) ?></option>
                                            <option value="01">January</option>
                                            <option value="02">February</option>
                                            <option value="03">March</option>
                                            <option value="04">April</option>
                                            <option value="05">May</option>
                                            <option value="06">June</option>
                                            <option value="07">July</option>
                                            <option value="08">August</option>
                                            <option value="09">September</option>
                                            <option value="10">October</option>
                                            <option value="11">November</option>
                                            <option value="12">December</option>
                                          </select>
                                        </div>
                                        <div class="col-lg-2 center-block">
                                           <label class='control-label'>&nbsp;</label>
                                            <select name="day" id="monthcom2" class="form-control pull-left">
                                                <option selected hidden value="<?php echo date('j',strtotime($Birthdate)) ?>"><?php echo date('j',strtotime($Birthdate)) ?></option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                                <option value="4">4</option>
                                                <option value="5">5</option>
                                                <option value="6">6</option>
                                                <option value="7">7</option>
                                                <option value="8">8</option>
                                                <option value="9">9</option>
                                                <option value="10">10</option>
                                                <option value="11">11</option>
                                                <option value="12">12</option>
                                                <option value="13">13</option>
                                                <option value="14">14</option>
                                                <option value="15">15</option>
                                                <option value="16">16</option>
                                                <option value="17">17</option>
                                                <option value="18">18</option>
                                                <option value="19">19</option>
                                                <option value="20">20</option>
                                                <option value="21">21</option>
                                                <option value="22">22</option>
                                                <option value="23">23</option>
                                                <option value="24">24</option>
                                                <option value="25">25</option>
                                                <option value="26">26</option>
                                                <option value="27">27</option>
                                                <option value="28">28</option>
                                                <option value="29">29</option>
                                                <option value="30">30</option>
                                                <option value="31">31</option>
                                          </select>
                                        </div>                                        
                                        <div class="col-lg-2 center-block">
                                            <label class='control-label'>&nbsp;</label>
                                            <select name="year" class="form-control pull-left" id="monthcom3">
                                              <option select hidden><?php echo date('Y',strtotime($Birthdate)) ?></option>
                                            </select>
                                        </div>
                                          <div class="col-lg-5  center-block">
                                            <label class='control-label'>Place of Birth</label>
                                           <input type="text" placeholder="Town, Province, Country(if not local)" name="pob" class ='form-control pull-left' value="<?php echo $Birthplace;?>">
                                        </div>
                                  </div>
                                  <div class="row">                                 
                                      <div class="col-lg-4  center-block">
                                        <label class='control-label'>Religion</label>
                                        <input type="text" name="rel" class="form-control pull-left" value="<?php echo $Religion;?>">
                                       
                                    </div>
                                    
                                    <div class="col-lg-4 center-block">
                                       <label class='control-label'>Gender</label>
                                       <select name="gen" class="form-control pull-left">
                                   <!--      <option hidden></option> -->
                                        <option selected hidden><?php echo $Sex;?></option>
                                        <option >Male</option>
                                        <option >Female</option>    
                                      </select>
                                    </div>
                                    <div class="col-lg-4 center-block">
                                        <label class='control-label'>Civil Status</label>
                                        <select name="cs" id="cs" class="form-control pull-left">
                                         <option selected hidden><?php echo $CivilStat;?></option>
                                        <option>Single</option>
                                        <option>Married</option>
                                        <option>Widowed</option>
                                        <option>Separated</option>
                                        <option>Live-In</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div class="row"><div class="col-lg-3 center-block">
                                         <label class='control-label '>Height</label>
                                          <input type="text" name="height" placeholder = 'feet & inches' class ='form-control pull-left' value="<?php echo $Height;?>">
                                      </div><div class="col-lg-3 center-block">
                                           <label class='control-label '>Disability</label>
                                         <select type="text" name="dis" class ='form-control pull-left'>
                                          <option selected hidden><?php echo $Disability;?></option>
                                          <option hidden></option>
                                          <option>None</option>
                                          <option>Hearing</option>
                                          <option>Physical</option>
                                          <option>Visual</option>
                                          <option>Speech</option>
                                          <option>Others</option>
                                         </select>
                                      </div> <div class="col-lg-3 center-block">
                                           <label class='control-label '>Landline No.</label>
                                    
                                         <input type="text" name="landnum" class ='form-control pull-left ' value="<?php echo $Landline;?>">
                                         
                                      </div>

                                      <div class="col-lg-3 center-block">
                                                <label class='control-label ' >Contact No.</label>
                                         <input type="text" name="connum" class ='form-control pull-left ' value="<?php echo $ContactNum;?>">
                                         
                                    </div>
                                  </div> 
                                </div><!-- END CARD-BODY -->
                            </div><!-- END CARD-->
                            <hr>  
                            <!-- address information -->
                            
                            <!-- END CARD--> 
                          
                            <!-- id number -->   
                            
                          </div>
                        </div>

</div>
</div>


<div class="row">
  <div class="col-lg-8">

     <div class="box box-primary">
            <div class="box-header with-border">
              <i class="fa fa-home"></i><h3 class="box-title">Address Information</h3>   
            </div>
            <!-- /.box-header -->
            <div class="box-body">
             <div class="card mb-3">
                                
                                <div class="card-body"  style="padding-left: 20px;padding-right: 20px">
                                    <div class="row">
                                        <label class='control-label'>Street Address</label>
                                        <input type="text" name="street" class ='form-control pull-left street' value="<?php echo $Street;?>">  
                                    </div>
                                    <div class="row">
                                        <label class='control-label '>Barangay</label>
                                        <input type="text" name="bar" class ='form-control pull-left bar' value="<?php echo $Barangay;?>">
                                    </div>
                                    <div class="row">
                                        <label class='control-label'>Town</label>
                                        <select id="citySel" size="1" class ='form-control pull-left' name="town" required>
                                            <option selected="selected" disabled hidden><?php echo $Town;?></option>
                                        </select>
                                    </div>
                                    <div class="row">
                                      <label class='control-label'>Province</label>
                                      <select id="stateSel" size="1" class ='form-control pull-left' name="prov" required>
                                        <option value="TEST" selected="selected" disabled hidden><?php echo $Province;?></option>
                                      </select>
                                    </div>
                                    <div class="row">
                                      <label for="countySel">Region<span style="color:red;">*</span></label>
              <select id="countySel" size="1" class ='form-control pull-left' required>
                    <option value="TEST" selected="selected" disabled hidden>-- Select Region --</option>
              </select>
                                    </div>

                                </div><!-- END CARD-BODY -->
                            </div>
            </div>
            <!-- /.box-body -->
          </div>
  </div>
  <div class="col-lg-4">
    
     <div class="box box-primary">
            <div class="box-header with-border">
              <i class="fa fa-list-ol"></i><h3 class="box-title">Identification Numbers</h3> 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
             <div class="card mb-3">
                               
                                   
                          
                                <div class="card-body"  style="padding: 15px 20px 10px 20px">
                                    <div class="row">
                                      <label class='control-label '>TIN No.</label>
                                      <input type="text" name="tin" class ='form-control pull-left' value="<?php echo $TIN;?>">
                                    </div>
                                    <div class="row">
                                      <label class='control-label '>GSIS/SSS No.</label>
                                      <input type="text" name="gsss" class ='form-control pull-left street' value="<?php echo $GSIS_SSS;?>">
                                    </div>
                                    <div class="row">
                                        <label class='control-label '>Philhealth No.</label>
                                       <input type="text" name="philh" class ='form-control pull-left' value="<?php echo $PhilHealth;?>">
                                    </div>
                                </div><!-- END CARD-BODY -->
                            </div><!-- END CARD-->
                            <input type="submit" class="btn btn-info btn-block" value="Update">
            </div>
            <!-- /.box-body -->
          </div>

  </div>

</div>
                          

                         


                        



                   </form>      
                </div>

                      </div><!-- END BOX BODY -->
                  </div><!-- END BOX PRIMARY -->
            




<?php 
// include('fragments/jobseeker/jobseeker_profile_fragments.php');
// include('fragments/jobseeker/jobseeker_profile_fragments_edit.php');
include('fragments/profile_footer.php');
?>



<script src="assets/js/register_places.js"></script>
<script src="assets/js/jobseeker_profile.js"></script>
<script>
 
   

$('#monthcom2').on('click',function(){
       var x = document.getElementById("monthcom").value;
       var y = document.getElementById("monthcom2");
       
       if(x == 'February' && y.value > 29){
      
      y.value = 29;
}else if(x == 'April' || x == 'June' || x == 'September' || x == 'November' && y.value > 30){

  y.remove(31);
}
    });
$('#monthcom').on('change',function(){
       var x2 = document.getElementById("monthcom").value;
       var y2 = document.getElementById("monthcom2");
       
        if(x2 == 'January' || x2 == 'March' || x2 == 'May' || x2 == 'July' || x2 == 'August'){
            y2.remove(30);
            y2.remove(30);
            y2.options[y2.options.length] = new Option('30', '30');
            y2.options[y2.options.length] = new Option('31', '31');                
        }else if(x2 == 'February'){ 
       y2.remove(30);
       y2.remove(30);
}else if(x2 == 'April' || x2 == 'June' || x2 == 'September' || x2 == 'November'){     
       y2.remove(30);
       y2.remove(30);
       y2.options[y2.options.length] = new Option('30', '30');
}
    });
    var currentTime = new Date();
var year = currentTime.getFullYear();
for (i = year ; i > 1949; i--) {
  var m = document.getElementById("monthcom3");
    m.options[m.options.length] = new Option(i, i);

}
 </script>


