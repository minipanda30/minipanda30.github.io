<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jobseekerresume extends CI_Controller {

 function __construct()
 {
   parent::__construct();
   $this->load->model('Jobseeker_management_model','jmm');
 }
	public function index()
	{
		if($this->session->userdata('logged_in')){
				$session_data = $this->session->userdata('logged_in');
				$data['userAccID'] = $this->session->userdata('logged_in')['userAccID'];
				$data['access'] = $this->session->userdata('logged_in')['access'];
			if($data['access'] == 'master'){
				$this->load->view('jobseeker_admin_view');
			}elseif($data['access'] =='admin'){
				$this->load->view('jobseeker_admin_view');
			}elseif($data['access'] =='peso'){
				$this->load->view('dashboard_view');
			}elseif($data['access'] =='company'){
				$this->load->view('dashboard_view');
			}else{
				$data = $this->jmm->view_resume();
				
				$this->load->view('jobseeker_upload_resume',$data);
			}
				
			
		}else{
				redirect('signin','refresh');
		}
	}

	

	 
	 
}
