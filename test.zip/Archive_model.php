<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Archive_model extends CI_Model {

    // var $table = 'accounts';
    // var $column = array('username,password,type');
    // var $order = array('account_id' => 'desc');

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function save_profpic($where, $data)
    {
        $this->db->update('tbl_jobseeker', $data, $where);
        return $this->db->affected_rows();
    }

    public function save_companypic($where, $data){
        $this->db->update('tbl_company', $data, $where);
        return $this->db->affected_rows();
    }

    public function save_resume($data){

         $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker');

        $this->db->where('jobseeker_id',$query->row(0)->seeker_id);
        $this->db->update('tbl_jobseeker_uploads', $data);
        return $this->db->affected_rows();
    }
}

