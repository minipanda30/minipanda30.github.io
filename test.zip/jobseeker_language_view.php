<?php 
include ('fragments/profile_header.php');
include('fragments/profile_nav.php');
?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
             <div class="col-md-3">
                  <!-- profile image -->
                 <div class="box box-primary">
                      <div class="box-body box-profile">
                        <a href="jobseekerupload"><img class="profile-user-img img-responsive" src="<?php echo $jprofpic;?>" alt="User profile picture" style="width: 100px;height: 100px;"></a>

                        <h3 class="profile-username text-center"><?php echo $jfname.' '.$jlname;?></h3>
                        <ul class="list-group list-group-unbordered">
                          <li class="list-group-item">
                           <a href="jobseeker"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Personal Information</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerother"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-reorder"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Additional Information</b></span></button> </a>
                          </li>
                         <li class="list-group-item">
                            <a href="jobseekerprefwork"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-cubes"></i> &nbsp;&nbsp;&nbsp;&nbsp;<b>Job Preference</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerlanguage"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-comments-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Langauge and Dialect Proficiency</b></span></button> </a>
                          </li>
                          
                          <li class="list-group-item">
                            <a href="jobseekereduc"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-graduation-cap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Educational Background</b></span></button> </a>
                          </li>
                           <li class="list-group-item">
                            <a href="jobseekertrain"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-sitemap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Techinical/Vocational &amp; Other Trainings</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerelig"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-credit-card"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Eligibility/ Professional License</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerexp"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-suitcase"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Work Experience</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerskills"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-list-alt"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Other Skills</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerresume"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-files-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Upload Resume</b></span></button> </a>
                          </li>
                        </ul>
                      </div>
                      <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
              </div>

              <!-- PROFILE DETAILS -->
             <div class="col-md-9">
              <form action="Jobseeker/update_lang" method="post">
              <div class="box box-primary">
            <div class="box-header with-border">
              <i class="fa fa-list-ol"></i><h3 class="box-title">Identification Numbers</h3> 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
             <div class="card mb-3">
                               
                                   
                          
                                <div class="card-body"  style="padding: 15px 20px 10px 20px">
                                 <div class="row" >
  <div class="col-lg-3" id="language">
   <div class="row"><div class="col-lg-12 center-block"><label class='control-label '>Language/Dialect You Can Read</label></div></div>
<div class="row">
    <div class="col-lg-12 center-block">
       
       <div class="input-group">
      
      <input type="text" class="form-control" name='language[]' value='<?php echo $lr[0]; ?>'>
      <span class="input-group-addon">
        <button class="btn btn-secondary" type="button" id="addl"><i class="fa fa-plus"></i></button>
      </span>
    </div>

    </div>
  </div>


  <?php if($lr != null){$x4 = count($lr);}else{$x4 = 0;} if($x4 > 1){for($i4=1;$i4<$x4;$i4++){echo '<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><input type="text" class="form-control"  name="language[]" value="'.$lr[$i4].'"><span class="input-group-addon"><button class="btn btn-danger delete4'.$i4.'" type="button"><i class="fa fa-times"></i></button></span></div></div></div>';}}?>
    
  </div>
  <div class="col-lg-3" id="language2">
   <div class="row"><div class="col-lg-12 center-block"><label class='control-label '>Language/Dialect You Can Write</label></div></div>
<div class="row">
    <div class="col-lg-12 center-block">
       
       <div class="input-group">
      
      <input type="text" class="form-control" name='language2[]' value='<?php echo $lw[0]; ?>'>
      <span class="input-group-addon">
        <button class="btn btn-secondary" type="button" id="addl2"><i class="fa fa-plus"></i></button>
      </span>
    </div>

    </div>
  </div>


  <?php if($lw != null){$x5 = count($lw);}else{$x5 = 0;} if($x5 > 1){for($i5=1;$i5<$x5;$i5++){echo '<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><input type="text" class="form-control"  name="language2[]" value="'.$lw[$i5].'"><span class="input-group-addon"><button class="btn btn-danger delete5'.$i5.'" type="button"><i class="fa fa-times"></i></button></span></div></div></div>';}}?>
    
  </div>
  <div class="col-lg-3" id="language3">
   <div class="row"><div class="col-lg-12 center-block"><label class='control-label '>Language/Dialect You Can Speak</label></div></div>
<div class="row">
    <div class="col-lg-12 center-block">
       
       <div class="input-group">
      
      <input type="text" class="form-control" name='language3[]' value='<?php echo $ls[0]; ?>'>
      <span class="input-group-addon">
        <button class="btn btn-secondary" type="button" id="addl3"><i class="fa fa-plus"></i></button>
      </span>
    </div>

    </div>
  </div>

   <?php if($ls != null){$x6 = count($ls);}else{$x6 = 0;} if($x6 > 1){for($i6=1;$i6<$x6;$i6++){echo '<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><input type="text" class="form-control"  name="language3[]" value="'.$ls[$i6].'"><span class="input-group-addon"><button class="btn btn-danger delete6'.$i6.'" type="button"><i class="fa fa-times"></i></button></span></div></div></div>';}}?>
    
  </div>
  <div class="col-lg-3" id="language4">
   <div class="row"><div class="col-lg-12 center-block"><label class='control-label '>Language/Dialect You Understand</label></div></div>
<div class="row">
    <div class="col-lg-12 center-block">
       
       <div class="input-group">
      
      <input type="text" class="form-control" name='language4[]' value='<?php echo $lu[0]; ?>'>
      <span class="input-group-addon">
        <button class="btn btn-secondary" type="button" id="addl4"><i class="fa fa-plus"></i></button>
      </span>
    </div>

    </div>
  </div>

    <?php if($lu != null){$x7 = count($lu);}else{$x7 = 0;} if($x7 > 1){for($i7=1;$i7<$x7;$i7++){echo '<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><input type="text" class="form-control"  name="language4[]" value="'.$lu[$i7].'"><span class="input-group-addon"><button class="btn btn-danger delete7'.$i7.'" type="button"><i class="fa fa-times"></i></button></span></div></div></div>';}}?>
    
  </div>
</div>
 <div class="row">
    <div class="col-lg-4"></div>
    <div class="col-lg-4"></div>
  <div class="col-lg-4">
    <br>
   <input type="submit" class="btn btn-info btn-block pull-right" value="Update"></div></div>
                                </div><!-- END CARD-BODY -->
                            </div><!-- END CARD-->
                           
            </div>
            <!-- /.box-body -->
          </div>
                   </form>      
                </div>

                      </div><!-- END BOX BODY -->
                  </div><!-- END BOX PRIMARY -->
            




<?php 
// include('fragments/jobseeker/jobseeker_profile_fragments.php');
// include('fragments/jobseeker/jobseeker_profile_fragments_edit.php');
include('fragments/profile_footer.php');
?>




<script src="assets/js/jobseeker_profile.js"></script>
<script>
 var max_fields4      = 10;
    var wrapper4         = $("#language");
    var add_button4      = $("#addl");
  
    var a = 1;
    $(add_button4).click(function(e){
     
         
        if(a < max_fields4){


  
  
            $(wrapper4).append('<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><input type="text" class="form-control" name="language[]"><span class="input-group-addon"><button class="btn btn-danger delete4" type="button"><i class="fa fa-times"></i></button></span></div></div></div>');

        }
  else
  {
  alert('You Reached the limits')
  }


   $('.delete4').click(function(e){
        e.preventDefault();$(this).closest('.row').remove(); x--;
    });

    });

    <?php
  if($lr != null){$x = count($lr);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '$(".delete4'.$i.'").click(function(e){
        e.preventDefault();$(".delete4'.$i.'").closest(".row").remove();
    });';}}
?>




    var max_fields5      = 10;
    var wrapper5        = $("#language2");
    var add_button5      = $("#addl2");
  
    var b = 1;
    $(add_button5).click(function(e){
     
         
        if(b < max_fields5){


  
  
            $(wrapper5).append('<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><input type="text" class="form-control" name="language2[]"><span class="input-group-addon"><button class="btn btn-danger delete5" type="button"><i class="fa fa-times"></i></button></span></div></div></div>');

        }
  else
  {
  alert('You Reached the limits')
  }


   $('.delete5').click(function(e){
        e.preventDefault();$(this).closest('.row').remove(); x--;
    });

    });

<?php
  if($lw != null){$x = count($lw);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '$(".delete5'.$i.'").click(function(e){
        e.preventDefault();$(".delete5'.$i.'").closest(".row").remove();
    });';}}
?>

    var max_fields6      = 10;
    var wrapper6        = $("#language3");
    var add_button6  = $("#addl3");
  
    var c = 1;
    $(add_button6).click(function(e){
     
         
        if(c < max_fields6){


  
  
            $(wrapper6).append('<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><input type="text" class="form-control" name="language3[]"><span class="input-group-addon"><button class="btn btn-danger delete6" type="button"><i class="fa fa-times"></i></button></span></div></div></div>');

        }
  else
  {
  alert('You Reached the limits')
  }


   $('.delete6').click(function(e){
        e.preventDefault();$(this).closest('.row').remove(); x--;
    });

    });

<?php
  if($ls != null){$x = count($ls);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '$(".delete6'.$i.'").click(function(e){
        e.preventDefault();$(".delete6'.$i.'").closest(".row").remove();
    });';}}
?>


     var max_fields7      = 10;
    var wrapper7        = $("#language4");
    var add_button7  = $("#addl4");
  
    var d = 1;
    $(add_button7).click(function(e){
     
         
        if(d < max_fields7){
            $(wrapper7).append('<div class="row" style="padding-top:5px"><div class="col-lg-12 center-block"><div class="input-group"><input type="text" class="form-control"  name="language4[]"><span class="input-group-addon"><button class="btn btn-danger delete7" type="button"><i class="fa fa-times"></i></button></span></div></div></div>');}
  else{alert('You Reached the limits') }

   $('.delete7').click(function(e){
        e.preventDefault();$(this).closest('.row').remove(); x--;
    });



    }); 
    

   <?php
  if($lu != null){$x = count($lu);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '$(".delete7'.$i.'").click(function(e){
        e.preventDefault();$(".delete7'.$i.'").closest(".row").remove();
    });';}}
?>

 </script>


