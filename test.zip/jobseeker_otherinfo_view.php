<?php 
include ('fragments/profile_header.php');
include('fragments/profile_nav.php');
?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
             <div class="col-md-3">
                  <!-- profile image -->
                  <div class="box box-primary">
                      <div class="box-body box-profile">
                        <a href="jobseekerupload"><img class="profile-user-img img-responsive" src="<?php echo $jprofpic;?>" alt="User profile picture" style="width: 100px;height: 100px;"></a>
                        <h3 class="profile-username text-center"><?php echo $jfname.' '.$jlname;?></h3>
                        <ul class="list-group list-group-unbordered">
                          <li class="list-group-item">
                           <a href="jobseeker"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Personal Information</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerother"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-reorder"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Additional Information</b></span></button> </a>
                          </li>
                         <li class="list-group-item">
                            <a href="jobseekerprefwork"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-cubes"></i> &nbsp;&nbsp;&nbsp;&nbsp;<b>Job Preference</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerlanguage"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-comments-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Langauge and Dialect Proficiency</b></span></button> </a>
                          </li>
                          
                          <li class="list-group-item">
                            <a href="jobseekereduc"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-graduation-cap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Educational Background</b></span></button> </a>
                          </li>
                           <li class="list-group-item">
                            <a href="jobseekertrain"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-sitemap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Techinical/Vocational &amp; Other Trainings</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerelig"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-credit-card"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Eligibility/ Professional License</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerexp"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-suitcase"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Work Experience</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerskills"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-list-alt"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Other Skills</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerresume"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-files-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Upload Resume</b></span></button> </a>
                          </li>
                        </ul>
                      </div>
                      <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
              </div>

              <!-- PROFILE DETAILS -->
             <div class="col-md-9">
              <form action="Jobseeker/add_additional_information" method="post">
              <div class="box box-primary">
            <div class="box-header with-border">
              <i class="fa fa-list-ol"></i><h3 class="box-title">Identification Numbers</h3> 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
             <div class="card mb-3">
                               
                                   
                          
                                <div class="card-body"  style="padding: 15px 20px 10px 20px">

                          


<div class="row">
    
    
      
    <div class="col-lg-3 center-block">
         <label class='control-label '>Employment Status</label>
        <select name="emp" id="empstat" class="form-control pull-left">
          <option selected hidden><?php if(isset($EmploymentStatus)){echo $EmploymentStatus;}else{echo "Employed";} ?></option>
        <option>Employed</option>
        <option>Unemployed</option>
        
      </select>
    </div>
    <div class="col-lg-4 center-block">
         <label class='control-label '>Employment Type</label>
        <select name="empre"  class="form-control pull-left">
        <option selected hidden><?php if(isset($EmploymentType)){echo $EmploymentType;}else{echo "New Entrant/Fresh Graduate";} ?></option>
        <option>Self Employed</option>
          <option>Wage Employed</option>
         <option>New Entrant/Fresh Graduate</option>
       <option>Finished Contract</option>
       <option>Resigned</option>
       <option>Retired</option>
          <option>Terminated/Laidoff (Local)</option>
        <option>Terminated/Laidoff (Local)</option>
      </select>
    </div>


   <div class="col-lg-2 center-block">
        <label class='control-label '>4P Beneficiary?</label>
        <select name="fourp" id="fourp" class="form-control pull-left">
          <option selected hidden><?php if(isset($FPs)){echo $FPs;}else{echo "No";} ?></option>

        <option>Yes</option>
        <option>No</option>
        
      </select>
    </div>
    
   
    <div class="col-lg-3 center-block">
        <label class='control-label '>If yes, Household No.</label>
      <input type="text" name="fourpre" id="fourpre" class ='form-control pull-left conper' value='
<?php echo $FPsNum; ?>'>
    </div>


  </div>




<br>
                  <div class="row">
 <div class="col-lg-1 center-block">
        <label class='control-label '>Expected Salary</label>
    </div>
    <div class="col-lg-3 center-block">
       
      <input type="text" name="expw" class ='form-control pull-left' value='<?php echo $ExpectedSalary; ?>'>
    </div>
    <div class="col-lg-1 center-block">
        <label class='control-label '>Passport No.</label>
    </div>
    <div class="col-lg-3 center-block">
       
      <input type="text" name="passp" id="passp" class ='form-control pull-left' value='<?php echo $PassportNumber; ?>'>
    </div>
     <div class="col-lg-1 center-block">
       <label class='control-label '>Expiry Date</label>
    </div>
    <div class="col-lg-3 center-block">
       
       <input type="text" name="expdatepass" id="exppass" class ='form-control pull-left' placeholder="yyyy-mm-dd" value='<?php echo $PassportExpiryDate; ?>'>
    </div>
     
</div>   



 <div class="row">
    <div class="col-lg-4"></div>
    <div class="col-lg-4"></div>
  <div class="col-lg-4">
    <br>
   <input type="submit" class="btn btn-info btn-block pull-right" value="Update"></div></div>
                                </div><!-- END CARD-BODY -->
                            </div><!-- END CARD-->
                           
            </div>
            <!-- /.box-body -->
          </div>
                   </form>      
                </div>

                      </div><!-- END BOX BODY -->
                  </div><!-- END BOX PRIMARY -->
            




<?php 
// include('fragments/jobseeker/jobseeker_profile_fragments.php');
// include('fragments/jobseeker/jobseeker_profile_fragments_edit.php');
include('fragments/profile_footer.php');
?>




<script src="assets/js/jobseeker_profile.js"></script>
<script>
   if($('#fourp').val() == "Yes"){

  $('#fourpre').attr('disabled', false);
}else{$('#fourpre').attr('disabled', true);}

if($('#willwork').val() == "No"){

  $('#willre').attr('disabled', false);
}else{$('#willre').attr('disabled', true);}

if($('#passp').val() != ""){

  $('#exppass').attr('disabled', false);
}else{$('#exppass').attr('disabled', true);}


    $('#fourp').change(function(e){
if($('#fourp').val() == "Yes"){

  $('#fourpre').attr('disabled', false);
}else{$('#fourpre').attr('disabled', true);}

    });

     $('#willwork').change(function(e){
if($('#willwork').val() == "No"){

  $('#willre').attr('disabled', false);
}else{$('#willre').attr('disabled', true);}

    });

     $('#passp').keyup(function(e){
if($('#passp').val() != ""){

  $('#exppass').attr('disabled', false);
}else{$('#exppass').attr('disabled', true);}

    });
 </script>


