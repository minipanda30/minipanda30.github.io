<?php 
include ('fragments/profile_header.php');
include('fragments/profile_nav.php');
?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
             <div class="col-md-3">
                  <!-- profile image -->
                 <div class="box box-primary">
                      <div class="box-body box-profile">
                        <a href="jobseekerupload"><img class="profile-user-img img-responsive" src="<?php echo $jprofpic;?>" alt="User profile picture" style="width: 100px;height: 100px;"></a>

                        <h3 class="profile-username text-center"><?php echo $jfname.' '.$jlname;?></h3>
                        <ul class="list-group list-group-unbordered">
                          <li class="list-group-item">
                           <a href="jobseeker"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Personal Information</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerother"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-reorder"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Additional Information</b></span></button> </a>
                          </li>
                         <li class="list-group-item">
                            <a href="jobseekerprefwork"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-cubes"></i> &nbsp;&nbsp;&nbsp;&nbsp;<b>Job Preference</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerlanguage"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-comments-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Langauge and Dialect Proficiency</b></span></button> </a>
                          </li>
                          
                          <li class="list-group-item">
                            <a href="jobseekereduc"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-graduation-cap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Educational Background</b></span></button> </a>
                          </li>
                           <li class="list-group-item">
                            <a href="jobseekertrain"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-sitemap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Techinical/Vocational &amp; Other Trainings</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerelig"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-credit-card"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Eligibility/ Professional License</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerexp"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-suitcase"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Work Experience</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerskills"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-list-alt"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Other Skills</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerresume"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-files-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Upload Resume</b></span></button> </a>
                          </li>
                        </ul>
                      </div>
                      <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
              </div>

              <!-- PROFILE DETAILS -->
             <div class="col-md-9">
              <form action="Jobseeker/update_experience" method="post">
              <div class="box box-primary">
            <div class="box-header with-border">
              <i class="fa fa-list-ol"></i><h3 class="box-title">WorkExperience</h3> 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
           <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-suitcase"></i>
        Limit to 10 Year Period, Start With the Most Recent Employment</div>
        <div class="card-body">
          <form action = '<?php echo base_url("update5"); ?>' method = "POST" class = "form-horizontal">

<br>
<br>
<div class="row">
 <div class="col-lg-12"  id="educ">

<div class="row" style="padding-top:5px">
  <div class="col-lg-3 center-block"><input type="text" class="form-control" placeholder="Company Name" name="exp1[]" value="<?php echo $jcompname[0]; ?>"></div>
  <div class="col-lg-3 center-block"><input type="text" class="form-control" placeholder="Address" name="exp2[]" value="<?php echo $jcompadd[0]; ?>"></div>
  <div class="col-lg-2 center-block"><input type="text" class="form-control" placeholder="Position" name="exp3[]" value="<?php echo $jtrainpos[0]; ?>"></div>
  <div class="col-lg-2 center-block"><input type="text" class="form-control" placeholder="Inclusive Dates" title="mm/yyyy to mm/yyyy" name="exp4[]" value="<?php echo $jincdate[0]; ?>"></div>
  <div class="col-lg-2 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Status" name="exp5[]" value="<?php echo $jworkstatus[0]; ?>"><span class="input-group-addon"><button class="btn btn-secondary" type="button" id="addbtn"><i class="fa fa-plus"></i></button></span></div></div
  ></div>

<?php
  if($jcompname != null){$x = count($jcompname);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '
  <div class="row" style="padding-top:5px">
  <div class="col-lg-3 center-block"><input type="text" class="form-control" placeholder="Company Name" name="exp1[]" value="'.$jcompname[$i].'"></div><div class="col-lg-3 center-block"><input type="text" class="form-control" placeholder="Address" name="exp2[]" value="'.$jcompadd[$i].'"></div>
  <div class="col-lg-2 center-block"><input type="text" class="form-control" placeholder="Position" name="exp3[]" value="'.$jtrainpos[$i].'"></div>
  <div class="col-lg-2 center-block"><input type="text" class="form-control" placeholder="Inclusive Dates" title="mm/yyyy to mm/yyyy" name="exp4[]" value="'.$jincdate[$i].'"></div>
  <div class="col-lg-2 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Status" name="exp5[]" value="'.$jworkstatus[$i].'"><span class="input-group-addon"><button class="btn btn-danger delete'.$i.'" type="button"><i class="fa fa-times"></i></button></span></div></div></div>';}}
?>



</div>
     </div>
    


<br>



 <div class="row">
    <div class="col-lg-4"></div>
    <div class="col-lg-4"></div>
  <div class="col-lg-4">
    <br>
   <input type="submit" class="btn btn-info btn-block pull-right" value="Update"></div></div>
<br>
<br>
<br>
     
</form>
        </div>
       
      </div>
                           
            </div>
            <!-- /.box-body -->
          </div>
                   </form>      
                </div>

                      </div><!-- END BOX BODY -->
                  </div><!-- END BOX PRIMARY -->
            




<?php 
// include('fragments/jobseeker/jobseeker_profile_fragments.php');
// include('fragments/jobseeker/jobseeker_profile_fragments_edit.php');
include('fragments/profile_footer.php');
?>




<script src="assets/js/jobseeker_profile.js"></script>
<script>
 
 
var max_fields      = 10;
    var wrapper2         = $("#educ");
    var add_button2      = $("#addbtn");
  
    var y = 1;
    $(add_button2).click(function(e){
     
         
        if(y < max_fields){
            $(wrapper2).append('<div class="row" style="padding-top:5px"><div class="col-lg-3 center-block"><input type="text" class="form-control" placeholder="Company Name" name="exp1[]"></div><div class="col-lg-3 center-block"><input type="text" class="form-control" placeholder="Address" name="exp2[]"></div><div class="col-lg-2 center-block"><input type="text" class="form-control" placeholder="Position" name="exp3[]"></div><div class="col-lg-2 center-block"><input type="text" class="form-control" placeholder="Inclusive Dates" name="exp4[]"></div><div class="col-lg-2 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Status" name="exp5[]"><span class="input-group-addon"><button class="btn btn-danger delete2" type="button"><i class="fa fa-times"></i></button></span></div></div></div>');}
 else
  {
  alert('You Reached the limits')
  }


   $('.delete2').click(function(e){
        e.preventDefault();$(this).closest('.row').remove();;
    });

    });


<?php
  if($jcompname != null){$x = count($jcompname);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '$(".delete'.$i.'").click(function(e){
        e.preventDefault();$(".delete'.$i.'").closest(".row").remove();
    });';}}
?>


 </script>


