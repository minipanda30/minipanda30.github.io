<?php
  
   class Upload extends CI_Controller {
   
      public function __construct() { 
         parent::__construct(); 
         $this->load->helper(array('form', 'url'));
         $this->load->model('Archive_model', 'archive') ;
      }
      
      public function index() { 
         $this->load->view('upload_form', array('error' => ' ' )); 
      } 
      
           public function do_upload_profpic() { 
         $config['upload_path']   = './uploads/Jobseeker/'. md5($this->input->post('jobseeker_id')).'/'.$this->input->post('folder_name'); 
         $config['allowed_types'] = 'gif|jpg|png|pdf'; 
         $config['max_size']      = 25000; 
         $config['max_width']     = 2048; 
         $config['max_height']    = 1536;  
         // chmod($config['upload_path'], 777);
         $this->load->library('upload', $config);
         $this->upload->initialize($config);
         if (!is_dir('uploads/Jobseeker/'.md5($this->input->post('jobseeker_id')).'/'.$this->input->post('folder_name'))) {
            mkdir('./uploads/Jobseeker/' .md5($this->input->post('jobseeker_id')).'/'.$this->input->post('folder_name'), 0777, TRUE);
         }

         if ( ! $this->upload->do_upload('userfile')) {
            $error = array('error' => $this->upload->display_errors()); 
            // $this->load->view('home_view', $error); 
            var_dump($error);
                     }
         
         else { 
            $data = array('upload_data' => $this->upload->data()); 
            // redirect('jobseekerupload','refresh');
            $this->save_profpic();
         } 
      }

      public function save_profpic(){
         $file = $_FILES['userfile'];
         $name = $file['name'];
         $data = array(
            'Picture' => 'uploads/Jobseeker/'.md5($this->input->post('jobseeker_id')).'/'.$this->input->post('folder_name').'/'.$name
            );
         $id = $this->session->userdata('logged_in')['jid'];
         $this->archive->save_profpic(array('seeker_id' => $id), $data);
         echo json_encode(array("status" => TRUE));
         redirect('signin', 'refresh');
      }

      public function do_upload_companypic() { 
         $config['upload_path']   = './uploads/Company/'. md5($this->input->post('company_id')).'/'.$this->input->post('folder_name'); 
         $config['allowed_types'] = 'gif|jpg|png|pdf'; 
         $config['max_size']      = 25000; 
         $config['max_width']     = 2048; 
         $config['max_height']    = 1536;  
         // chmod($config['upload_path'], 777);
         $this->load->library('upload', $config);
         $this->upload->initialize($config);
         if (!is_dir('uploads/Company/'.md5($this->input->post('company_id')).'/'.$this->input->post('folder_name'))) {
            mkdir('./uploads/Company/' .md5($this->input->post('company_id')).'/'.$this->input->post('folder_name'), 0777, TRUE);
         }

         if ( ! $this->upload->do_upload('userfile')) {
            $error = array('error' => $this->upload->display_errors()); 
            // $this->load->view('home_view', $error); 
            var_dump($error);
                     }
         
         else { 
            $data = array('upload_data' => $this->upload->data()); 
            // redirect('jobseekerupload','refresh');
            $this->save_companypic();
         } 
      }

      public function save_companypic(){
         $file = $_FILES['userfile'];
         $name = $file['name'];
         $data = array(
            'CompanyImage' => 'uploads/Company/'.md5($this->input->post('company_id')).'/'.$this->input->post('folder_name').'/'.$name
            );
         $id = $this->session->userdata('logged_in')['cid'];
         $this->archive->save_companypic(array('company_id' => $id), $data);
         echo json_encode(array("status" => TRUE));
         redirect('signin', 'refresh');
      }

      public function do_upload(){
         $config['upload_path']   = './uploads/Jobseeker/'. md5($this->input->post('jobseeker_id')).'/'.$this->input->post('folder_name'); 
         $config['allowed_types'] = 'gif|jpg|png|pdf'; 
         $config['max_size']      = 25000; 
         $config['max_width']     = 2048; 
         $config['max_height']    = 1536;  
         // chmod($config['upload_path'], 777);
         $this->load->library('upload', $config);
         $this->upload->initialize($config);
         if (!is_dir('uploads/Jobseeker/'.md5($this->input->post('jobseeker_id')).'/'.$this->input->post('folder_name'))) {
            mkdir('./uploads/Jobseeker/' .md5($this->input->post('jobseeker_id')).'/'.$this->input->post('folder_name'), 0777, TRUE);
         }

         if ( ! $this->upload->do_upload('userfile')) {
            $error = array('error' => $this->upload->display_errors()); 
            // $this->load->view('home_view', $error); 
            var_dump($error);
         }else { 
            $data = array('upload_data' => $this->upload->data()); 
            // redirect('jobseekerupload','refresh');
            // var_dump('SUCCESS');
            $this->save_resume();
         } 
      }

      public function save_resume(){
         $file = $_FILES['userfile'];
         $name = $file['name'];
         $data = array(
            'File_Name' => $name,
            'File_Path' => 'uploads/Jobseeker/'.md5($this->input->post('jobseeker_id')).'/'.$this->input->post('folder_name').'/'.$name,
            'DateUploaded' => date('Y-m-d')
            );
         $this->archive->save_resume($data);
         echo json_encode(array("status" => TRUE));
         redirect('signin', 'refresh');
      }
      
   } 
?>