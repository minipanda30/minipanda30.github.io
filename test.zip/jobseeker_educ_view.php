<?php 
include ('fragments/profile_header.php');
include('fragments/profile_nav.php');
?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
             <div class="col-md-3">
                  <!-- profile image -->
                 <div class="box box-primary">
                      <div class="box-body box-profile">
                        <a href="jobseekerupload"><img class="profile-user-img img-responsive" src="<?php echo $jprofpic;?>" alt="User profile picture" style="width: 100px;height: 100px;"></a>

                        <h3 class="profile-username text-center"><?php echo $jfname.' '.$jlname;?></h3>
                        <ul class="list-group list-group-unbordered">
                          <li class="list-group-item">
                           <a href="jobseeker"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Personal Information</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerother"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-reorder"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Additional Information</b></span></button> </a>
                          </li>
                         <li class="list-group-item">
                            <a href="jobseekerprefwork"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-cubes"></i> &nbsp;&nbsp;&nbsp;&nbsp;<b>Job Preference</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerlanguage"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-comments-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Langauge and Dialect Proficiency</b></span></button> </a>
                          </li>
                          
                          <li class="list-group-item">
                            <a href="jobseekereduc"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-graduation-cap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Educational Background</b></span></button> </a>
                          </li>
                           <li class="list-group-item">
                            <a href="jobseekertrain"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-sitemap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Techinical/Vocational &amp; Other Trainings</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerelig"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-credit-card"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Eligibility/ Professional License</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerexp"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-suitcase"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Work Experience</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerskills"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-list-alt"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Other Skills</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerresume"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-files-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Upload Resume</b></span></button> </a>
                          </li>
                        </ul>
                      </div>
                      <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
              </div>

              <!-- PROFILE DETAILS -->

             <div class="col-md-9">
              <form action="Jobseeker/update_edu" method="post">



            <div class="row">
              <div class="col-lg-12">  
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <i class="fa fa-list-ol"></i><h3 class="box-title">Primary Education</h3> 
                  </div>
            <!-- /.box-header -->
            <div class="box-body">
            <div class="card mb-3">
      
        <div class="card-body">
         <div class="col-sm-12"  id="educ">
<div class="row">
   <div class="col-sm-6">
      
       <input type="text" placeholder="School Name" name="primary[]" class ='form-control pull-left' value='<?php echo "$primary[0]"; ?>'>
    </div>
    <div class="col-sm-6">
     
       <div class="input-group">
      
      <input type="text" class="form-control" placeholder="Year Graduated" name='primarydate[]' value='<?php echo "$primdate[0]"; ?>'>
      <span class="input-group-addon">
        <button class="btn btn-secondary" type="button" id="addbtn"><i class="fa fa-plus"></i></button>
      </span>
    </div>

    </div>



</div>


<?php if($primary != null){$x = count($primary);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '<div class="row" style="padding-top:5px"><div class="col-sm-6 center-block"><input type="text" class="form-control" name="primary[]" value="'.$primary[$i].'"></div><div class="col-sm-6 center-block"><div class="input-group"><input type="text" class="form-control" name="primarydate[]" value="'.$primdate[$i].'"><span class="input-group-addon"><button class="btn btn-danger delete'.$i.'" type="button"><i class="fa fa-times"></i></button></span></div></div></div>';}}?>



</div>
        </div>
      
      </div>
                           
            </div>
            <!-- /.box-body -->
          </div></div>

          <div class="col-lg-12">  
                <div class="box box-primary">
            <div class="box-header with-border">
              <i class="fa fa-list-ol"></i><h3 class="box-title">Secondary Education</h3> 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <div class="card mb-3">
        
        <div class="card-body">
         <div class="row">
 <div class="col-sm-12"  id="educ2">
<div class="row">
   <div class="col-sm-6">     
       <input type="text" placeholder="School Name" name="secondary[]" class ='form-control pull-left' value='<?php echo "$secondary[0]"; ?>'>
    </div>
    <div class="col-sm-6">
       
       <div class="input-group">
      
      <input type="text" class="form-control" placeholder="Year Graduated" name='secondarydate[]' value='<?php echo "$secdate[0]"; ?>'>
      <span class="input-group-addon">
        <button class="btn btn-secondary" type="button" id="addbtn2"><i class="fa fa-plus"></i></button>
      </span>
    </div>

    </div>



</div>

<?php if($secondary != null){$x2 = count($secondary);}else{$x2 = 0;} if($x2 > 1){for($i2=1;$i2<$x2;$i2++){echo '<div class="row" style="padding-top:5px"><div class="col-sm-6 center-block"><input type="text" class="form-control" name="secondary[]" value="'.$secondary[$i2].'"></div><div class="col-sm-6 center-block"><div class="input-group"><input type="text" class="form-control" name="secondarydate[]" value="'.$secdate[$i2].'"><span class="input-group-addon"><button class="btn btn-danger delete2'.$i2.'" type="button"><i class="fa fa-times"></i></button></span></div></div></div>';}}?>


</div>
     </div>
        </div>
       
      </div>
                           
            </div>
            <!-- /.box-body -->
          </div></div>
            </div>





















            <div class="row">
              <div class="col-lg-12">  
                <div class="box box-primary">
            <div class="box-header with-border">
              <i class="fa fa-list-ol"></i><h3 class="box-title">College Education</h3> 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <div class="card mb-3">
       
        <div class="card-body">
         <div class="row">
 <div class="col-sm-12"  id="educ3">
<div class="row">
  <div class="col-sm-4">     
       <input type="text" placeholder="School Name" name="college[]" class ='form-control pull-left' value='<?php echo "$tertiary[0]"; ?>'>
    </div>
   <div class="col-sm-4">     
       <input type="text" placeholder="Course" name="course[]" class ='form-control pull-left' value='<?php echo "$course[0]"; ?>'>
    </div>
    <div class="col-sm-4">
       
       <div class="input-group">
      
      <input type="text" class="form-control" placeholder="Year Graduated" name='collegedate[]' value='<?php echo "$terdate[0]"; ?>'>
      <span class="input-group-addon">
        <button class="btn btn-secondary" type="button" id="addbtn3"><i class="fa fa-plus"></i></button>
      </span>
    </div>

    </div>



</div>

<?php if($tertiary != null){$x3 = count($tertiary);}else{$x3 = 0;} if($x3 > 1){for($i3=1;$i3<$x3;$i3++){echo '<div class="row" style="padding-top:5px"><div class="col-sm-4 center-block"><input type="text" class="form-control" placeholder="Year Graduated" name="college[]" value="'.$tertiary[$i3].'"></div><div class="col-sm-4"><input type="text" placeholder="Course" name="course[]" class ="form-control pull-left" value="'.$course[$i3].'"></div><div class="col-sm-2 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Year Graduated" name="collegedate[]" value="'.$terdate[$i3].'"><span class="input-group-addon"><button class="btn btn-danger delete3'.$i3.'" type="button"><i class="fa fa-times"></i></button></span></div></div></div>';}}?>


</div>
     </div>
        </div>
      </div>
                           
            </div>
            <!-- /.box-body -->
          </div></div>

          <div class="col-lg-12">  
                <div class="box box-primary">
            <div class="box-header with-border">
              <i class="fa fa-list-ol"></i><h3 class="box-title">if Undergraduate</h3> 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <div class="card mb-3">
      
        <div class="card-body">
         <div class="col-sm-12"  id="educ">
          <div class="row">
  
    <div class="col-sm-6 center-block">
      
       <select name="underg"  class="form-control pull-left" id="ugrad">
         <option value="<?php if(isset($undergrad)){echo $undergrad;}else{echo "Not Undergrad";} ?>" selected hidden ><?php if(isset($undergrad)){echo $undergrad;}else{echo "What Level?";} ?></option>
        <option value="Not Undergrad">Not Undergrad</option>
        <option value="Primary">Primary</option>
        <option value="Secondary">Secondary</option>
        <option value="Tertiary">Tertiary</option>
        
      </select>
    </div>

    <div class="col-sm-6 center-block">
          
       <input type="text" id="ugradr" placeholder="Year Last Attended" name="yrlast" class ='form-control pull-left' value="<?php echo $yrlast; ?>">
    </div>
     
  
</div>
</div>
</div>
</div>              
</div>
<!-- /.box-body -->
</div>
</div>

          <div class="col-lg-12">  
                <div class="box box-primary">
            <div class="box-header with-border">
              <i class="fa fa-list-ol"></i><h3 class="box-title">Awards Received</h3> 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <div class="card mb-3">
      
        <div class="card-body">
         <div class="col-sm-12"  id="educ">
          <div class="row">
  
    <div class="col-sm-2 center-block">
    </div>
    <div class="col-sm-8 center-block">  
       <input type="text" id="awards" placeholder="Awards Received" name="awards" class ='form-control pull-left' value="<?php echo $awards; ?>">

    </div>
    <div class="col-sm-2 center-block">
    </div>
     
  
</div>
<div class="row">
    <div class="col-lg-4"></div>
    <div class="col-lg-4"></div>
  <div class="col-lg-4">
    <br>
   <input type="submit" class="btn btn-info btn-block pull-right" value="Update"></div></div>
</div>
</div>
</div>              
</div>
<!-- /.box-body -->
</div>
</div>


 

            </div>
                   </form>      
                </div>

                      </div><!-- END BOX BODY -->
                  </div><!-- END BOX PRIMARY -->
            




<?php 
// include('fragments/jobseeker/jobseeker_profile_fragments.php');
// include('fragments/jobseeker/jobseeker_profile_fragments_edit.php');
include('fragments/profile_footer.php');
?>




<script src="assets/js/jobseeker_profile.js"></script>
<script>
 if($('#ugrad').val() == "Primary" || $('#ugrad').val() == "Secondary" || $('#ugrad').val() == "Tertiary" ){

  $('#ugradr').attr('disabled', false);
}else{$('#ugradr').attr('disabled', true);}

 $('#ugrad').change(function(e){
if($('#ugrad').val() == "Primary" || $('#ugrad').val() == "Secondary" || $('#ugrad').val() == "Tertiary"){

  $('#ugradr').attr('disabled', false);
}else{$('#ugradr').attr('disabled', true);}

    });




    var max_fields      = 10;
    var wrapper         = $("#educ");
    var add_button      = $("#addbtn");
  
    var x = 1;
    $(add_button).click(function(e){
     
         
        if(x < max_fields){
            $(wrapper).append('<div class="row" style="padding-top:5px"><div class="col-sm-6 center-block"><input type="text" class="form-control" placeholder="School Name" name="primary[]"></div><div class="col-sm-6 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Year Graduated" name="primarydate[]"><span class="input-group-addon"><button class="btn btn-danger delete" type="button"><i class="fa fa-times"></i></button></span></div></div></div>');}
 else
  {
  alert('You Reached the limits')
  }


   $('.delete').click(function(e){
        e.preventDefault();$(this).closest('.row').remove(); x--;
    });

    });


 <?php
  if($primary != null){$x = count($primary);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '$(".delete'.$i.'").click(function(e){
        e.preventDefault();$(".delete'.$i.'").closest(".row").remove();
    });';}}
?>


var max_fields      = 10;
    var wrapper2         = $("#educ2");
    var add_button2      = $("#addbtn2");
  
    var y = 1;
    $(add_button2).click(function(e){
     
         
        if(y < max_fields){
            $(wrapper2).append('<div class="row" style="padding-top:5px"><div class="col-sm-6 center-block"><input type="text" class="form-control" placeholder="School Name" name="secondary[]"></div><div class="col-sm-6 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Year Graduated" name="secondarydate[]"><span class="input-group-addon"><button class="btn btn-danger delete2" type="button"><i class="fa fa-times"></i></button></span></div></div></div>');}
 else
  {
  alert('You Reached the limits')
  }


   $('.delete2').click(function(e){
        e.preventDefault();$(this).closest('.row').remove(); x--;
    });

    });

  <?php
  if($secondary != null){$x = count($secondary);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '$(".delete2'.$i.'").click(function(e){
        e.preventDefault();$(".delete2'.$i.'").closest(".row").remove();
    });';}}
?>

var max_fields      = 10;
    var wrapper3        = $("#educ3");
    var add_button3      = $("#addbtn3");
  
    var z = 1;
    $(add_button3).click(function(e){
     
         
        if(z < max_fields){
            $(wrapper3).append('<div class="row" style="padding-top:5px"><div class="col-sm-4 center-block"><input type="text" class="form-control" placeholder="Year Graduated" name="college[]"></div><div class="col-sm-4"><input type="text" placeholder="Course" name="course[]" class ="form-control pull-left"></div><div class="col-sm-4 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Year Graduated" name="collegedate[]"><span class="input-group-addon"><button class="btn btn-danger delete3" type="button"><i class="fa fa-times"></i></button></span></div></div></div>');}
 else
  {
  alert('You Reached the limits')
  }

$('.delete3').click(function(e){
        e.preventDefault();$(this).closest('.row').remove(); x--;
    });
  
    });

 <?php
  if($tertiary != null){$x = count($tertiary);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '$(".delete3'.$i.'").click(function(e){
        e.preventDefault();$(".delete3'.$i.'").closest(".row").remove();
    });';}}
?>



var max_fields4      = 10;
    var wrapper4        = $("#educ4");
    var add_button4      = $("#addbtn4");
  
    var a = 1;
    $(add_button4).click(function(e){
     
         
        if(a < max_fields4){
            $(wrapper4).append('<div class="row" style="margin-top: 8px"><div class="col-sm-12"><div class="input-group"><input type="text" class="form-control" name="awards[]"><span class="input-group-addon"><button class="btn btn-danger delete4" type="button"><i class="fa fa-times"></i></button> </span></div></div></div>');}
 else
  {
  alert('You Reached the limits')
  }


   $('.delete4').click(function(e){
        e.preventDefault();$(this).closest('.row').remove(); x--;
    });

    });

   <?php
  if($awards != null){$x = count($awards);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++){echo '$(".delete4'.$i.'").click(function(e){
        e.preventDefault();$(".delete4'.$i.'").closest(".row").remove();
    });';}}
?>



 </script>


