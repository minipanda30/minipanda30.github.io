<?php 
include ('fragments/profile_header.php');
include('fragments/profile_nav.php');
?>



  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
             <div class="col-md-3">
                  <!-- profile image -->
                 <div class="box box-primary">
                      <div class="box-body box-profile">
                        <a href="jobseekerupload"><img class="profile-user-img img-responsive" src="<?php echo $jprofpic;?>" alt="User profile picture" style="width: 100px;height: 100px;"></a>

                        <h3 class="profile-username text-center"><?php echo $jfname.' '.$jlname;?></h3>
                        <ul class="list-group list-group-unbordered">
                          <li class="list-group-item">
                           <a href="jobseeker"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Personal Information</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerother"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-reorder"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Additional Information</b></span></button> </a>
                          </li>
                         <li class="list-group-item">
                            <a href="jobseekerprefwork"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-cubes"></i> &nbsp;&nbsp;&nbsp;&nbsp;<b>Job Preference</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerlanguage"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-comments-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Langauge and Dialect Proficiency</b></span></button> </a>
                          </li>
                          
                          <li class="list-group-item">
                            <a href="jobseekereduc"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-graduation-cap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Educational Background</b></span></button> </a>
                          </li>
                           <li class="list-group-item">
                            <a href="jobseekertrain"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-sitemap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Techinical/Vocational &amp; Other Trainings</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerelig"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-credit-card"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Eligibility/ Professional License</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerexp"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-suitcase"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Work Experience</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerskills"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-list-alt"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Other Skills</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerresume"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-files-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Upload Resume</b></span></button> </a>
                          </li>
                        </ul>
                      </div>
                      <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
              </div>

              <!-- PROFILE DETAILS -->
             <div class="col-md-9">
              <form action="Jobseeker/update_eligibility" method="post">
              <div class="box box-primary">
            <div class="box-header with-border">
              <i class="fa fa-list-ol"></i><h3 class="box-title">Eligibility and Licenses</h3> 
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-list-alt"></i> Fill Up With All Eligibility and Professional License You Possess</div>
        <div class="card-body">
        <form action = '<?php echo base_url("update4"); ?>' method = "POST" class = "form-horizontal">

<br>
<br>
<div class="row">
 <div class="col-lg-12"  id="educ">
<div class="row"><div class="col-lg-6">Eligibility</div></div>
<div class="row" style="padding-top:5px">
  <div class="col-lg-4 center-block"><input type="text" class="form-control" placeholder="Eligibility(Civil Service)" name="eli[0]" value="<?php echo $elig[0]; ?>"></div><div class="col-lg-4 center-block" ><input type="text" class="form-control" placeholder="Rating" name="eli2[]" value="<?php echo $rat[0]; ?>"></div><div class="col-lg-4 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Date of Exam" name="eli3[]" value="<?php echo $date[0]; ?>"><span class="input-group-addon"><button class="btn btn-secondary" type="button" id="addbtn"><i class="fa fa-plus"></i></button></span></div></div></div>


  


<?php
if($elig != null){$x = count($elig);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++)
{echo '<div class="row" style="padding-top:5px">
  <div class="col-lg-4 center-block"><input type="text" class="form-control" placeholder="Eligibility(Civil Service)" name="eli[]" value="'.$elig[$i].'"></div><div class="col-lg-4 center-block"><input type="text" class="form-control" placeholder="Rating" name="eli2[]" value="'.$rat[$i].'"></div><div class="col-lg-4 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Date of Exam" name="eli3[]" value="'.$date[$i].'"><span class="input-group-addon"><button class="btn btn-danger delete2'.$i.'" type="button" ><i class="fa fa-times"></i></button></span></div></div></div>';}}
?>

</div>
     </div>
<br>

     <div class="row">
 <div class="col-lg-12"  id="educ2">


<div class="row"><div class="col-lg-6">Professional License</div></div>
<div class="row" style="padding-top:5px">
  <div class="col-lg-6 center-block"><input type="text" class="form-control" placeholder="Professional License(PRC)" name="eli4[]" value="<?php echo $pro[0]; ?>"></div><div class="col-lg-6 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Valid Until" name="eli5[]" value="<?php echo $valid[0]; ?>"><span class="input-group-addon"><button class="btn btn-secondary" type="button" id="addbtn3"><i class="fa fa-plus"></i></button></span></div></div> </div> 


<?php
if($pro != null){$x = count($pro);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++)
{echo '<div class="row" style="padding-top:5px">
  <div class="col-lg-6 center-block"><input type="text" class="form-control" placeholder="Professional License(PRC)" name="eli4[]" value="'.$pro[$i].'"></div><div class="col-lg-6 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Valid Until" name="eli5[]" value="'.$valid[$i].'"><span class="input-group-addon"><button class="btn btn-danger delete3'.$i.'" type="button" ><i class="fa fa-times"></i></button></span></div></div></div>';}}
?>


</div> </div>
    


<br>


<div class="row">
    <div class="col-lg-4"></div>
    <div class="col-lg-4"></div>
  <div class="col-lg-4">
    <br>
   <input type="submit" class="btn btn-info btn-block pull-right" value="Update"></div></div>
<br>
<br>
<br>
     
</form>
        </div>
       
      </div>
                           
            </div>
            <!-- /.box-body -->
          </div>
                   </form>      
                </div>

                      </div><!-- END BOX BODY -->
                  </div><!-- END BOX PRIMARY -->
            




<?php 
// include('fragments/jobseeker/jobseeker_profile_fragments.php');
// include('fragments/jobseeker/jobseeker_profile_fragments_edit.php');
include('fragments/profile_footer.php');
?>




<script src="assets/js/jobseeker_profile.js"></script>
<script>
 

var max_fields      = 10;
    var wrapper2         = $("#educ");
    var add_button2      = $("#addbtn");
  
    var y = 1;
    $(add_button2).click(function(e){
     
         
        if(y < max_fields){
            $(wrapper2).append('<div class="row" style="padding-top:5px"><div class="col-lg-4 center-block"><input type="text" class="form-control" placeholder="Eligibility(Civil Service)" name="eli[]"></div><div class="col-lg-4 center-block"><input type="text" class="form-control" placeholder="Rating" name="eli2[]"></div><div class="col-lg-4 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Date of Exam" name="eli3[]"><span class="input-group-addon"><button class="btn btn-danger delete2" type="button" ><i class="fa fa-times"></i></button></span></div></div></div>');}
 else
  {
  alert('You Reached the limits')
  }


   $('.delete2').click(function(e){
        e.preventDefault();$(this).closest('.row').remove();;
    });

    });

<?php
if($elig != null){$x = count($elig);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++)
{echo "$('.delete2".$i."').click(function(e){e.preventDefault();$('.delete2".$i."').closest('.row').remove();});";}} ?>





var max_fields2      = 10;
    var wrapper         = $("#educ2");
    var add_button      = $("#addbtn3");
  
    var y = 1;
    $(add_button).click(function(e){
     
         
        if(y < max_fields2){
            $(wrapper).append('<div class="row" style="padding-top:5px"><div class="col-lg-6 center-block"><input type="text" class="form-control" placeholder="Professional License(PRC)" name="eli4[]"></div><div class="col-lg-6 center-block"><div class="input-group"><input type="text" class="form-control" placeholder="Valid Until" name="eli5[]"><span class="input-group-addon"><button class="btn btn-danger delete3" type="button" ><i class="fa fa-times"></i></button></span></div></div></div>');}
 else
  {
  alert('You Reached the limits')
  }


   $('.delete3').click(function(e){
        e.preventDefault();$(this).closest('.row').remove();;
    });

    });

<?php
if($pro != null){$x = count($pro);}else{$x = 0;} if($x > 1){for($i=1;$i<$x;$i++)
{echo "$('.delete3".$i."').click(function(e){
        e.preventDefault();$('.delete3".$i."').closest('.row').remove();
    });";}} ?>


 </script>


