<?php 
include ('fragments/profile_header.php');
include('fragments/profile_nav.php');
?>
 <script>function bs_input_file() {
  $(".input-file").before(
    function() {
      if ( ! $(this).prev().hasClass('input-ghost') ) {
        var element = $("<input type='file' class='input-ghost' style='visibility:hidden; height:0'>");
        element.attr("name",$(this).attr("name"));
        element.change(function(){
          element.next(element).find('input').val((element.val()).split('\\').pop());
        });
        $(this).find("button.btn-choose").click(function(){
          element.click();
        });
        $(this).find("button.btn-reset").click(function(){
          element.val(null);
          $(this).parents(".input-file").find('input').val('');
        });
        $(this).find('input').css("cursor","pointer");
        $(this).find('input').mousedown(function() {
          $(this).parents('.input-file').prev().click();
          return false;
        });
        return element;
      }
    }
  );
}
$(function() {
  bs_input_file();
});</script>

<?php
$jprofpic = $this->session->userdata('logged_in')['jprofpic'];
              $jid = $this->session->userdata('logged_in')['jid'];
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <!-- Main content -->
    <section class="content">
        <div class="row">
             <div class="col-md-3">
                  <!-- profile image -->
                  <div class="box box-primary">
                      <div class="box-body box-profile">
                        <a href="jobseekerupload"><img class="profile-user-img img-responsive" src="<?php echo $jprofpic;?>" alt="User profile picture" style="width: 100px;height: 100px;"></a>

                        <h3 class="profile-username text-center"><?php echo $jfname.' '.$jlname;?></h3>
                        <ul class="list-group list-group-unbordered">
                          <li class="list-group-item">
                           <a href="jobseeker"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-user"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Personal Information</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerother"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-reorder"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Additional Information</b></span></button> </a>
                          </li>
                         <li class="list-group-item">
                            <a href="jobseekerprefwork"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-cubes"></i> &nbsp;&nbsp;&nbsp;&nbsp;<b>Job Preference</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerlanguage"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-comments-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Langauge and Dialect Proficiency</b></span></button> </a>
                          </li>
                          
                          <li class="list-group-item">
                            <a href="jobseekereduc"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-graduation-cap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Educational Background</b></span></button> </a>
                          </li>
                           <li class="list-group-item">
                            <a href="jobseekertrain"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-sitemap"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Techinical/Vocational &amp; Other Trainings</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerelig"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-credit-card"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Eligibility/ Professional License</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerexp"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-suitcase"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Work Experience</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerskills"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-list-alt"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Other Skills</b></span></button> </a>
                          </li>
                          <li class="list-group-item">
                            <a href="jobseekerresume"><button class="btn btn-primary btn-block" ><span class="pull-left"> <i class="fa fa-files-o"></i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <b>Upload Resume</b></span></button> </a>
                          </li>
                        </ul>
                      </div>
                      <!-- /.box-body -->
                    </div>
                    <!-- /.box -->
              </div>

              <!-- PROFILE DETAILS -->
             <div class="col-md-9" id="myprofile">
              <div class="row">
                <div class="col-lg-12">
                    <div class="box box-primary">
                      <div class="box-header with-border">
                         <i class="fa fa-info-circle"></i><h3 class="box-title"> Upload Profile Picture </h3>
                      </div>              
                      <div class="box-body" id="background"> 
                        <div class="row">
                          <div class="col-md-4">
                      </div>
                      <div class="col-md-8">
              
              <form action="<?php echo site_url('upload/do_upload_profpic') ?>" id="uploadform" class="form-horizontal" method="POST" enctype="multipart/form-data">

        <?php 
        echo '<img id="blah" src="'.$jprofpic.'" alt="your image" width="250px" height="250px" />';?>
        
            <div class="form-group">
             <div class="btn btn-default btn-file btn-flat pull-right" style="margin-right:20px;">
              <i class="fa fa-paperclip"></i> Choose File
              <input type="file" name="userfile" id="imgInp">
            </div>
            <input type="hidden" value="Profile_Picture" name="folder_name"><br><br>
            <input type="hidden" name="jobseeker_id" id="jid" value="<?php echo $jid;?>">
            <input type="submit" value="Upload" class="btn btn-flat pull-right btn-black" style="margin-right:20px;" />
          </div>

        </form>
                      </div>

                      </div>

                       
                        </div>

</div>
</div>
</div>
</form>
</div>

            

                         


                        



                   </form>      
                </div>

                      </div><!-- END BOX BODY -->
                  </div><!-- END BOX PRIMARY -->
            




<?php 
// include('fragments/jobseeker/jobseeker_profile_fragments.php');
// include('fragments/jobseeker/jobseeker_profile_fragments_edit.php');
include('fragments/profile_footer.php');
?>




<script src="assets/js/jobseeker_profile.js"></script>
<script>
 function readURL(input) {

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#blah').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}

$("#imgInp").change(function(){
    readURL(this);
});

$("#imgInp").change(function(){
    readURL(this);
});
 </script>


