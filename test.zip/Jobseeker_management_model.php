<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Jobseeker_management_model extends CI_Model {
	public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    public function add_jobseeker_account($data){
        $this->db->insert('tbl_users', $data);
        return $this->db->insert_id();
    }

    public function validate($data1,$data2){
        $update = array(
            'Status' => 'activated',
            'Auth' => 'affirmative'
        );

        $this->db->where('useracc_id',$data1);
        $this->db->where('ConfirmCode',$data2);
        $this->db->update('tbl_users',$update);
        return $this->db->affected_rows();
    }

    public function add_jobseeker_profile($data1){
        $this->db->insert('tbl_jobseeker', $data1);
        return $this->db->insert_id();
    }

    public function get_all_jobseeker(){
        $this->db->from('tbl_jobseeker j');
        $this->db->join('tbl_users u','j.user_id = u.useracc_id','left');
        $this->db->where('u.Userlevel','jobseeker');
        $query = $this->db->get();
        return $query->result();
    }
    public function get_jobseeker_by_id($jobseeker_id)
    {
        $this->db->from('tbl_jobseeker j');
        $this->db->join('tbl_users u','j.user_id = u.useracc_id','left');
        $this->db->where('j.seeker_id', $jobseeker_id); 
        $query = $this->db->get();
        return $query->result();
    }

    public function get_active_specs()
    {
        $this->db->from('tbl_specialization s');
        $this->db->where('s.Status','active');
        $query = $this->db->get();
        return $query->result();
    }

    public function get_active_skills()
    {
        $this->db->from('tbl_skills s');
        $this->db->where('s.Skill_Status','active');
        $this->db->order_by('s.Skill_Name','ASC');
        $query = $this->db->get();
        return $query->result();
    }
    public function get_active_industry()
    {
        $this->db->from('tbl_industry i');
        $this->db->where('i.Status','active');
        $query = $this->db->get();
        return $query->result();
    }


    //profiling
    public function update_jobseeker_table($data){
         $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker');

        $this->db->where('seeker_id',$query->row(0)->seeker_id);
        $this->db->update('tbl_jobseeker', $data);
        return $this->db->affected_rows();
    }
        public function update_jobseeker_language($data){
        $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker');

        $this->db->where('jobseeker_id',$query->row(0)->seeker_id);
        $this->db->update('tbl_jobseeker_language', $data);
        return $this->db->affected_rows();
    }
    public function update_jobseeker_experience($data){
        $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker');

        $this->db->where('jobseeker_id',$query->row(0)->seeker_id);
        $this->db->update('tbl_jobseeker_experience', $data);
        return $this->db->affected_rows();
    }
    public function update_jobseeker_preference($data){

         $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker');

        $this->db->where('jobseeker_id',$query->row(0)->seeker_id);
        $this->db->update('tbl_jobseeker_preference', $data);
        return $this->db->affected_rows();  
    }
    public function update_jobseeker_education($data){
        $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker');

        $this->db->where('jobseeker_id',$query->row(0)->seeker_id);
        $this->db->update('tbl_jobseeker_educ', $data);
        return $this->db->affected_rows();
    }
    public function update_jobseeker_eligibilty($data){
        $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker');

        $this->db->where('jobseeker_id',$query->row(0)->seeker_id);
        $this->db->update('tbl_jobseeker_eligibility', $data);
        return $this->db->affected_rows();
    }

    
    public function update_jobseeker_techvoc($data){
        $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker');

        $this->db->where('jobseeker_id',$query->row(0)->seeker_id);
        $this->db->update('tbl_jobseeker_techvoc', $data);
        return $this->db->affected_rows();
    }
    public function update_jobseeker_uploads($where, $data){
        $this->db->update('tbl_jobseeker_preference', $data, $where);
        return $this->db->affected_rows();
    }

    public function view_profile()
    {
        $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker');
        return $query->row();
    }

    public function view_prefwork()
    {   $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_preference.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker_preference');


        if($query->num_rows() >0){
        $result = array(

        'pw' => unserialize(base64_decode($query->row(0)->PrefferedWork)),

'pwl' => unserialize(base64_decode($query->row(0)->PrefferedLocationLocal)),
'pwo' => unserialize(base64_decode($query->row(0)->PrefferedLocationAbroad   ) ));
 
    return $result;}else{  $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $getid = $this->db->get('tbl_jobseeker');



        $data = array( 
        'jobseeker_id'  =>  $getid->row(0)->seeker_id);
$this->db->insert('tbl_jobseeker_preference', $data);

 $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_preference.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query2 = $this->db->get('tbl_jobseeker_preference');

       $result = array(

        'pw' => unserialize(base64_decode($query2->row(0)->PrefferedWork)),

'pwl' => unserialize(base64_decode($query2->row(0)->PrefferedLocationLocal)),
'pwo' => unserialize(base64_decode($query2->row(0)->PrefferedLocationAbroad   ) ));
 
    return $result;}
    }




    public function view_language()
    {   $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_language.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker_language');

        if($query->num_rows() >0){
        $result = array(

        'lu' => unserialize(base64_decode($query->row(0)->LanguageUnder)),

'ls' => unserialize(base64_decode($query->row(0)->LanguageSpeak)),
'lw' => unserialize(base64_decode($query->row(0)->LanguageWrite   ) ),
'lr' => unserialize(base64_decode($query->row(0)->LanguageRead   ) ));
 
    return $result;}else{

         $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $getid = $this->db->get('tbl_jobseeker');



        $data = array( 
        'jobseeker_id'  =>  $getid->row(0)->seeker_id);
$this->db->insert('tbl_jobseeker_language', $data);

 $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_language.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query2 = $this->db->get('tbl_jobseeker_language');

        $result = array(

        'lu' => unserialize(base64_decode($query2->row(0)->LanguageUnder)),

'ls' => unserialize(base64_decode($query2->row(0)->LanguageSpeak)),
'lw' => unserialize(base64_decode($query2->row(0)->LanguageWrite   ) ),
'lr' => unserialize(base64_decode($query2->row(0)->LanguageRead   ) ));
 
    return $result; 

    }
    }

     public function view_other()
    {   $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker'); 
    return $query->row();
    }

     public function view_educ()
    {   $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_educ.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker_educ');

        if($query->num_rows() >0){
       $result = array(
'primary' => unserialize(base64_decode($query->row(0)->primary)),
'primdate' => unserialize(base64_decode($query->row(0)->primdate)),
'secondary' => unserialize(base64_decode($query->row(0)->secondary)),
'secdate' => unserialize(base64_decode($query->row(0)->secdate)),

'tertiary' => unserialize(base64_decode($query->row(0)->tertiary)),
'terdate' => unserialize(base64_decode($query->row(0)->terdate)),
'course' => unserialize(base64_decode($query->row(0)->course)),
'undergrad' => $query->row(0)->underg,
'yrlast' => $query->row(0)->yrlast,
'awards' => $query->row(0)->awards
);
 
    return $result;}else{

         $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $getid = $this->db->get('tbl_jobseeker');



        $data = array( 
        'jobseeker_id'  =>  $getid->row(0)->seeker_id);
$this->db->insert('tbl_jobseeker_educ', $data);

 $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_educ.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query2 = $this->db->get('tbl_jobseeker_educ');

       $result = array(
'primary' => unserialize(base64_decode($query2->row(0)->primary)),
'primdate' => unserialize(base64_decode($query2->row(0)->primdate)),
'secondary' => unserialize(base64_decode($query2->row(0)->secondary)),
'secdate' => unserialize(base64_decode($query2->row(0)->secdate)),

'tertiary' => unserialize(base64_decode($query2->row(0)->tertiary)),
'terdate' => unserialize(base64_decode($query2->row(0)->terdate)),
'course' => unserialize(base64_decode($query2->row(0)->course)),
'undergrad' => $query2->row(0)->underg,
'yrlast' => $query2->row(0)->yrlast,
'awards' => unserialize(base64_decode($query2->row(0)->awards))
);
 
    return $result; 

    }
    }


     public function view_train()
    {   $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_techvoc.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker_techvoc');

        if($query->num_rows() >0){
      $result = array(
'title' => unserialize(base64_decode($query->row(0)->TechVocCourse)),
'start' => unserialize(base64_decode($query->row(0)->TechTrainStart)),
'end' => unserialize(base64_decode($query->row(0)->TechTrainEnd)),
'trainin' => unserialize(base64_decode($query->row(0)->TrainInst)),
'certi' => unserialize(base64_decode($query->row(0)->TrainCert)),
);
 
    return $result;}else{

         $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $getid = $this->db->get('tbl_jobseeker');



        $data = array( 
        'jobseeker_id'  =>  $getid->row(0)->seeker_id);
$this->db->insert('tbl_jobseeker_techvoc', $data);

 $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_techvoc.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query2 = $this->db->get('tbl_jobseeker_techvoc');

      $result = array(
'title' => unserialize(base64_decode($query2->row(0)->TechVocCourse)),
'start' => unserialize(base64_decode($query2->row(0)->TechTrainStart)),
'end' => unserialize(base64_decode($query2->row(0)->TechTrainEnd)),
'trainin' => unserialize(base64_decode($query2->row(0)->TrainInst)),
'certi' => unserialize(base64_decode($query2->row(0)->TrainCert))
);
 
    return $result; 

    }
    }

     public function view_experience()
    { $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_experience.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker_experience');

        if($query->num_rows() >0){
      $result = array(
        'jcompname' => unserialize(base64_decode($query->row(0)->CompName)),
          'jcompadd' => unserialize(base64_decode($query->row(0)->CompAddress)),
          'jtrainpos' => unserialize(base64_decode($query->row(0)->TrainPos)), 
          'jincdate' =>unserialize(base64_decode($query->row(0)->InclusDate)), 
          'jworkstatus' => unserialize(base64_decode($query->row(0)->TrainStat)),
);
 
    return $result;}else{

         $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $getid = $this->db->get('tbl_jobseeker');



        $data = array( 
        'jobseeker_id'  =>  $getid->row(0)->seeker_id);
$this->db->insert('tbl_jobseeker_experience', $data);

 $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_experience.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query2 = $this->db->get('tbl_jobseeker_experience');

      $result = array(
          'jcompname' => unserialize(base64_decode($query2->row(0)->CompName)),
          'jcompadd' => unserialize(base64_decode($query2->row(0)->CompAddress)),
          'jcompind' => unserialize(base64_decode($query2->row(0)->CompIndustry)),
          'jcompspec' => unserialize(base64_decode($query2->row(0)->CompSpecialization)),
          'jrecpos' => unserialize(base64_decode($query2->row(0)->RecentPosition)),
          'jrecposlevel' => unserialize(base64_decode($query2->row(0)->RecentPositionLevel)),
          'jworkfromyr' => unserialize(base64_decode($query2->row(0)->WorkFromYr)),
          'jworkfrommonth' => unserialize(base64_decode($query2->row(0)->WorkFromMonth)),
          'jworkendyr' => unserialize(base64_decode($query2->row(0)->WorkEndYr)),
          'jworkendmonth' => unserialize(base64_decode($query2->row(0)->WorkEndMonth)),
          'jworkstatus' => unserialize(base64_decode($query2->row(0)->WorkStatus)),
);
 
    return $result; 

    }
    }


    public function view_elig()
    { $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_eligibility.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker_eligibility');

        if($query->num_rows() >0){
     $result = array(
'elig' => unserialize(base64_decode($query->row(0)->Eligibility)),
'rat' => unserialize(base64_decode($query->row(0)->Rating)),
'date' => unserialize(base64_decode($query->row(0)->ExamDate)),
'pro' => unserialize(base64_decode($query->row(0)->License)),
'valid' => unserialize(base64_decode($query->row(0)->LicenseExpiryDate))
);
 
    return $result;}else{

         $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $getid = $this->db->get('tbl_jobseeker');



        $data = array( 
        'jobseeker_id'  =>  $getid->row(0)->seeker_id);
$this->db->insert('tbl_jobseeker_eligibility', $data);

 $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_eligibility.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query2 = $this->db->get('tbl_jobseeker_eligibility');

     $result = array(
'elig' => unserialize(base64_encode($query2->row(0)->Eligibility)),
'rat' => unserialize(base64_encode($query2->row(0)->Rating)),
'date' => unserialize(base64_encode($query2->row(0)->ExamDate)),
'pro' => unserialize(base64_encode($query2->row(0)->License)),
'valid' => unserialize(base64_encode($query2->row(0)->LicenseExpiryDate))
);
 
    return $result; 

    }
    }

     public function view_skills()
    { $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_skill.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker_skill');

        if($query->num_rows() >0){
     $result = array(
'skill' => unserialize(base64_decode($query->row(0)->Skills)),

);
 
    return $result;}else{

         $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
        $getid = $this->db->get('tbl_jobseeker');



        $data = array( 
        'jobseeker_id'  =>  $getid->row(0)->seeker_id);
$this->db->insert('tbl_jobseeker_skill', $data);

 $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_skill.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query2 = $this->db->get('tbl_jobseeker_skill');

     $result = array(
'skill' => unserialize(base64_encode($query2->row(0)->Skills)),

);
 
    return $result; 

    }
    }
public function view_resume()
    { 
        $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_uploads.jobseeker_id');
        $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
        $query = $this->db->get('tbl_jobseeker_uploads');

        if($query->num_rows() >0){
                $result = array(
                        'FileName' => $query->row(0)->File_Name,
                        'FilePath' => $query->row(0)->File_Path,
                );
            return $result;
        }else{
                $this->db->where('user_id',$this->session->userdata('logged_in')['userAccID']);
                $getid = $this->db->get('tbl_jobseeker');
                $data = array( 
                    'jobseeker_id'  =>  $getid->row(0)->seeker_id
                );
                    $this->db->insert('tbl_jobseeker_uploads', $data);

                    $this->db->join('tbl_jobseeker','tbl_jobseeker.seeker_id = tbl_jobseeker_uploads.jobseeker_id');
                    $this->db->where('tbl_jobseeker.user_id',$this->session->userdata('logged_in')['userAccID']);
                    $query2 = $this->db->get('tbl_jobseeker_uploads');
                    $result = array(
                        'FileName' => $query2->row(0)->File_Name,
                        'FilePath' => $query2->row(0)->File_Path,
                        'DateUploaded' => $query2->row(0)->DateUploaded
                    );
            return $result; 
        }
    }

   public function update_jobseeker_skills($data){

 $this->db->where('user_id', $this->session->userdata('logged_in')['userAccID']);
 $query = $this->db->get('tbl_jobseeker');

            $this->db->where('jobseeker_id', $query->row(0)->seeker_id);
        $this->db->update('tbl_jobseeker_skill', $data);
        return $this->db->affected_rows();
    }

    public function select_skills(){

$this->db->select('Specialization_Name');
$this->db->from('tbl_specialization');
 $this->db->where('Status','active');
 $data = $this->db->get();
        return $data->result();
    }


}